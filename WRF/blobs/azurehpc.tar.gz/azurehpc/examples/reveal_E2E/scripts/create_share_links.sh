#!/bin/bash

ln -s /apps /share/apps
ln -s /data /share/data
