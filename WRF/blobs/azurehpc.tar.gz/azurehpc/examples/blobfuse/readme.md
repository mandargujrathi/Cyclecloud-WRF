### blobfuse

![Build Status](https://azurecat.visualstudio.com/hpccat/_apis/build/status/azhpc/examples/blobfuse?branchName=master)

adding blobfuse mount to blob storage
only available to the hpcadmin user (due to blobfuse design)
need to modify blobfuse settings to make rw to world
 
