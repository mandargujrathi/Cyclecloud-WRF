
Files in this directory are automatically synced to any node using this spec. Content here
can be anything from software packages to config files. Scripts can be used to install
software packages or move files into the appropriate location on the node.
            