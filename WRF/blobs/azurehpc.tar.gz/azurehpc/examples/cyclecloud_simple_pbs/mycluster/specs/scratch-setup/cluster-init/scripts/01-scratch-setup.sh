#!/bin/bash

chmod a+rwx /mnt/resource
ln -s /mnt/resource /scratch
