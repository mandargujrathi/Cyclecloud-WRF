
Files in this directory are executed on the host in alphabetical order.
It is recommended that files are named start with digits to ensure they
are executed in the correct order, example:
    - 000_run_me_first.sh
    - 001_run_me_second.sh

Allowable file extensions on Linux: .sh
Allowable file extensions on Windows: .bat, .cmd, .exe
            