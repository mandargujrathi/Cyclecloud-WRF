#!/bin/bash

systemctl stop waagent
