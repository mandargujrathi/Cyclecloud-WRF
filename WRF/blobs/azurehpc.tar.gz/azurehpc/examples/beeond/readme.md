![Build Status](https://azurecat.visualstudio.com/hpccat/_apis/build/status/azhpc/examples/beeond?branchName=master)

Visualisation: [config.json](https://azurehpc.azureedge.net/?o=https://raw.githubusercontent.com/Azure/azurehpc/master/examples/beeond/config.json)
