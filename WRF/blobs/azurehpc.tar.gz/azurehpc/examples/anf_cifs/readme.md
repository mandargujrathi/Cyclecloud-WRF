# Using ANF CIFS

ANF Cifs needs the ANF to be added to a Active Directory. For this, initially the AD need to be set up (since part of this is at the post-install level)


