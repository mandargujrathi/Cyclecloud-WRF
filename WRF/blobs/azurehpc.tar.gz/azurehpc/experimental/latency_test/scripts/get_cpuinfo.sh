#!/bin/bash

cat /proc/cpuinfo

