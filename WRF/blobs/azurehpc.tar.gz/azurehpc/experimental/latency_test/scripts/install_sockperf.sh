#!/bin/bash

yum -y install epel-release
yum -y install sockperf