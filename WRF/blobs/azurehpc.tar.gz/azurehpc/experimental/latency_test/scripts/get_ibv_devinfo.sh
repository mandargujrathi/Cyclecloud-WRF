#!/bin/bash

ibv_devinfo
