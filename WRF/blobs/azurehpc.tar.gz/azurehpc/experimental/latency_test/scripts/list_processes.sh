#!/bin/bash

ps -auwx
