#/bin/bash

systemctl start glusterd
systemctl status glusterd
