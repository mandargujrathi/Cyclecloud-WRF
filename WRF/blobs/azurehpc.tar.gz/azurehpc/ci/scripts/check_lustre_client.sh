#/bin/bash
LUSTRE_MOUNT=${1-/lustre}

lfs df
