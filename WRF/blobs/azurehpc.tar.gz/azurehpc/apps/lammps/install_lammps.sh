#!/bin/bash
sudo yum install -y epel-release
sudo yum install -y lammps

