#!/bin/bash
# Will use openmpi, gcc-9.2.0
# Will also build dependencies scalapack, openblas, fftw3

spack install quantum-espresso
