#!/bin/bash

sudo yum install -y libXt
