#!/bin/bash

sudo yum -y install freetype motif.x86_64 mesa-libGLU-9.0.0-4.el7.x86_64
